export default {
    tokenMsg:"",
    setToken:function(token){
        this.tokenMsg = token;
    }
}