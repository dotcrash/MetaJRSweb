// vue.config.js

const webpack = require("webpack");

module.exports = {
    // publicPath: '/',
    // outputDir: 'dist', // 打包的目录
    // lintOnSave: true, // 在保存时校验格式
    // productionSourceMap: false, // 生产环境是否生成 SourceMap
    devServer: {
        open: true, // 启动服务后是否打开浏览器
        hot: true,
        host: '0.0.0.0',
        port: 8080, // 服务端口
        https: false,
        hotOnly: false,
        // proxy: {},
        before: app => {}
    },
    configureWebpack: {
        plugins: [
            new webpack.ProvidePlugin({
                $: 'jquery',
                jQuery: 'jquery',
                'window.jQuery': 'jquery',
                Popper: ['popper.js', 'default']
            })
        ]
    }
}